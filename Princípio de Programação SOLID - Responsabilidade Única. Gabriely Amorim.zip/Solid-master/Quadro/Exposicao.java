public class Exposicao{
    public void NomedaPintura(string nomePintura)
    {
        System.out.println("Nome da Pintura", +nomePintura);
    }
}
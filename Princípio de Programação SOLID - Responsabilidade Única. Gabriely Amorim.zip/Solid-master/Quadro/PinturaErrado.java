public class PinturaErrado{
    String Nome;
    String Pintor;
    String Estilo;

	public String getNome() {
		return this.Nome;
	}

	public void setNome(String Nome) {
		this.Nome = Nome;
	}

	public String getPintor() {
		return this.Pintor;
	}

	public void setPintor(String Pintor) {
		this.Pintor = Pintor;
	}

	public String getEstilo() {
		return this.Estilo;
	}

	public void setEstilo(String Estilo) {
		this.Estilo = Estilo;
    }

   
    public void NomedaPintura(string nomePintura)
        {
            System.out.println("Nome da Pintura", +nomePintura);
        }
    }

  
}
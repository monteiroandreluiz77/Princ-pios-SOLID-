/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carrosi;

/**
 *
 * @author Andre
 */
public class Motocicleta implements AutomovelI{
    
       public String tipo;
     public String placa;
      public String cor;
      public boolean ligarMoto;

    public Motocicleta(String tipo, String placa, String cor, boolean ligarMoto) {
        this.tipo = tipo;
        this.placa = placa;
        this.cor = cor;
        this.ligarMoto = ligarMoto;
    }
      
      
    
    @Override
      public boolean acelerar(){
    
    if(ligarMoto != false){
        System.out.println("ram dam dam dam");
    } else{
        System.out.println("apagada");
    
    }

    return ligarMoto;
    
    }
      
       public void imprmir(){
         System.out.println("Tipo de Automóvel: "+tipo);
         System.out.println("Camaro Placa: "+placa);
         System.out.println("Camaro Cor: "+cor);
      
    }

}

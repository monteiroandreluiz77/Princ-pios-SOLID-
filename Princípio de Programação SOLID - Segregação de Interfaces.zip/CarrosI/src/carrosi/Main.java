/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carrosi;

/**
 *
 * @author Andre
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Carro hb20 = new Carro("Carro", "jgj384", "Amarelo", true, true);
        hb20.acelerar();
        hb20.arCondicionado();
        hb20.imprmir();
        
        
        System.out.println("\n");
        
        Motocicleta cb300 = new Motocicleta("Moto", "hjr2890", "Preta", true);
        cb300.acelerar();
        cb300.imprmir();
    }
    
}

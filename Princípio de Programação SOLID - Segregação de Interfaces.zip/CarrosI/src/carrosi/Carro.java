/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carrosi;

/**
 *
 * @author Andre
 */
public class Carro implements AutomovelI, ArCondicionadoI{
     
    public String tipo;
     public String placa;
      public String cor;
      public boolean ligarCarro;
       public boolean ligarAr;

    public Carro(String tipo, String placa, String cor, boolean ligarCarro, boolean ligarAr) {
        this.tipo = tipo;
        this.placa = placa;
        this.cor = cor;
        this.ligarCarro = ligarCarro;
        this.ligarAr = ligarAr;
    }
      


      @Override
      public boolean acelerar(){
    
    if(ligarCarro != false){
        System.out.println("Vruum");
    } else{
        System.out.println("Apagado");
    
    }

    return ligarCarro;
    
    }
      @Override
      public boolean arCondicionado(){
   
          if(ligarAr != false){
              System.out.println("Gelando");
    }
          else {
              System.out.println("Ar não está Funcionando!");
          }
          
          return ligarAr;
}

               
    public void imprmir(){
         System.out.println("Tipo de Automóvel: "+tipo);
         System.out.println("Camaro Placa: "+placa);
         System.out.println("Camaro Cor: "+cor);
      
    }

}

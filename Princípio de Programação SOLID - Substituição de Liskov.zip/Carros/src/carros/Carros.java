/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carros;

/**
 *
 * @author andre.monteiro
 */
public class Carros {
    
    public String placa;
    public String cor;
    public boolean ligar;

public boolean acelerar(){
    
    if(ligar != false){
        System.out.println("Vruum");
    } else{
           System.out.println("...");
    
    }

    return ligar;
    
    } 
}



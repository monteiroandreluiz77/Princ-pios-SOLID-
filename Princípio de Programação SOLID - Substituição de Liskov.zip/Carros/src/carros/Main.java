/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package carros;

/**
 *
 * @author andre.monteiro
 */
public class Main {
    public static void main(String[] args){
         Fusca fusca = new Fusca("fjh542\n", "Azul", true);
       
         fusca.imprmir();
         fusca.acelerar();
         
    System.out.println("\n");
            
    Camaro camaro = new Camaro("jfk525", "Amarelo", false);
    
    camaro.imprmir();
    camaro.acelerar();
    
            }
}

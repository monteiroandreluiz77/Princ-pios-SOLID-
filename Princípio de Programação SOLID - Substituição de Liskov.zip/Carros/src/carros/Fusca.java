/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carros;

/**
 *
 * @author andre.monteiro
 */
public class Fusca extends Carros{
    
    
    public Fusca(String placa, String cor, boolean ligar) {
        this.placa = placa;
        this.cor = cor;
        this.ligar = ligar;
    }
    
    public void imprmir(){
        System.out.println("Fusca cor: "+this.cor);
        System.out.println("Fusca Placa: "+this.placa);
    }

}

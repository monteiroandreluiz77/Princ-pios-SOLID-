package dependency;

public interface DDDRegiao {
	
	
	
	public int InserirDDD();

}

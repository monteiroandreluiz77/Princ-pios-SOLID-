package dependency;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Ligacao pravc = new Ligacao(new DDDGOiania(),993088888);
		
		pravc.discar();
	}}


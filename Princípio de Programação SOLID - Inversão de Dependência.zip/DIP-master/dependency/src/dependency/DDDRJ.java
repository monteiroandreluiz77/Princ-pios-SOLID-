package dependency;

public class DDDRJ implements DDDRegiao{

	

	@Override
	public int InserirDDD() {
		// TODO Auto-generated method stub
		return 22;
	}

}

package dependency;

public class DDDSP implements DDDRegiao{

	

	@Override
	public int InserirDDD() {
		// TODO Auto-generated method stub
		return  11;
		
	}

}

package dependency;

public class DDDGOiania implements DDDRegiao {

	
		
		
	

	@Override
	public int InserirDDD() {
		// TODO Auto-generated method stub
		return  62;
		
	}

}
